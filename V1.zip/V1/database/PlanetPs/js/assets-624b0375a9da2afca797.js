<!DOCTYPE html>
<html>
  <head>    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=3.0" name="viewport" />
<meta name="description" content="Growtopia Private Server community&#x27;s Private Server , chill and have fun here! Come join us today! | 68995 members" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:site" content="@discord" />
<meta name="twitter:title" content="Join the Growtopia Private Server | gtps.ps Discord Server!" />
<meta name="twitter:description" content="Growtopia Private Server community&#x27;s Private Server , chill and have fun here! Come join us today! | 68995 members" />
<meta property="og:title" content="Join the Growtopia Private Server | gtps.ps Discord Server!" />
<meta property="og:url" content="https://discord.com/invite/gtps3" />
<meta property="og:description" content="Growtopia Private Server community&#x27;s Private Server , chill and have fun here! Come join us today! | 68995 members" />
<meta property="og:site_name" content="Discord" />
<link rel="canonical" href="https://discord.com/invite/gtps3" />
<meta property="og:locale:alternate" content="nl" />
<meta property="og:locale:alternate" content="ar" />
<meta property="og:locale:alternate" content="ru" />
<meta property="og:locale:alternate" content="fr" />
<meta property="og:locale:alternate" content="ko" />
<meta property="og:locale:alternate" content="uk" />
<meta property="og:locale:alternate" content="th" />
<meta property="og:locale:alternate" content="he" />
<meta property="og:locale:alternate" content="fi" />
<meta property="og:locale:alternate" content="zh-TW" />
<meta property="og:locale:alternate" content="es-ES" />
<meta property="og:locale:alternate" content="hr" />
<meta property="og:locale:alternate" content="bg" />
<meta property="og:locale:alternate" content="ja" />
<meta property="og:locale:alternate" content="ro" />
<meta property="og:locale:alternate" content="vi" />
<meta property="og:locale:alternate" content="it" />
<meta property="og:locale" content="en-US" />
<meta property="og:locale:alternate" content="de" />
<meta property="og:locale:alternate" content="hi" />
<meta property="og:locale:alternate" content="pl" />
<meta property="og:locale:alternate" content="id" />
<meta property="og:locale:alternate" content="sv-SE" />
<meta property="og:locale:alternate" content="hu" />
<meta property="og:locale:alternate" content="lt" />
<meta property="og:locale:alternate" content="da" />
<meta property="og:locale:alternate" content="el" />
<meta property="og:locale:alternate" content="cs" />
<meta property="og:locale:alternate" content="no" />
<meta property="og:locale:alternate" content="tr" />
<meta property="og:locale:alternate" content="pt-BR" />
<meta property="og:locale:alternate" content="en-GB" />
<meta property="og:locale:alternate" content="zh-CN" />
<meta rel="alternate" hreflang="nl" href="https://discord.com/invite/gtps3?locale=nl" />
<meta rel="alternate" hreflang="ar" href="https://discord.com/invite/gtps3?locale=ar" />
<meta rel="alternate" hreflang="ru" href="https://discord.com/invite/gtps3?locale=ru" />
<meta rel="alternate" hreflang="fr" href="https://discord.com/invite/gtps3?locale=fr" />
<meta rel="alternate" hreflang="ko" href="https://discord.com/invite/gtps3?locale=ko" />
<meta rel="alternate" hreflang="uk" href="https://discord.com/invite/gtps3?locale=uk" />
<meta rel="alternate" hreflang="th" href="https://discord.com/invite/gtps3?locale=th" />
<meta rel="alternate" hreflang="he" href="https://discord.com/invite/gtps3?locale=he" />
<meta rel="alternate" hreflang="fi" href="https://discord.com/invite/gtps3?locale=fi" />
<meta rel="alternate" hreflang="zh-TW" href="https://discord.com/invite/gtps3?locale=zh-TW" />
<meta rel="alternate" hreflang="es-ES" href="https://discord.com/invite/gtps3?locale=es-ES" />
<meta rel="alternate" hreflang="hr" href="https://discord.com/invite/gtps3?locale=hr" />
<meta rel="alternate" hreflang="bg" href="https://discord.com/invite/gtps3?locale=bg" />
<meta rel="alternate" hreflang="ja" href="https://discord.com/invite/gtps3?locale=ja" />
<meta rel="alternate" hreflang="ro" href="https://discord.com/invite/gtps3?locale=ro" />
<meta rel="alternate" hreflang="vi" href="https://discord.com/invite/gtps3?locale=vi" />
<meta rel="alternate" hreflang="it" href="https://discord.com/invite/gtps3?locale=it" />
<meta rel="alternate" hreflang="en-US" href="https://discord.com/invite/gtps3?locale=en-US" />
<meta rel="alternate" hreflang="de" href="https://discord.com/invite/gtps3?locale=de" />
<meta rel="alternate" hreflang="hi" href="https://discord.com/invite/gtps3?locale=hi" />
<meta rel="alternate" hreflang="pl" href="https://discord.com/invite/gtps3?locale=pl" />
<meta rel="alternate" hreflang="id" href="https://discord.com/invite/gtps3?locale=id" />
<meta rel="alternate" hreflang="sv-SE" href="https://discord.com/invite/gtps3?locale=sv-SE" />
<meta rel="alternate" hreflang="hu" href="https://discord.com/invite/gtps3?locale=hu" />
<meta rel="alternate" hreflang="lt" href="https://discord.com/invite/gtps3?locale=lt" />
<meta rel="alternate" hreflang="da" href="https://discord.com/invite/gtps3?locale=da" />
<meta rel="alternate" hreflang="el" href="https://discord.com/invite/gtps3?locale=el" />
<meta rel="alternate" hreflang="cs" href="https://discord.com/invite/gtps3?locale=cs" />
<meta rel="alternate" hreflang="no" href="https://discord.com/invite/gtps3?locale=no" />
<meta rel="alternate" hreflang="tr" href="https://discord.com/invite/gtps3?locale=tr" />
<meta rel="alternate" hreflang="pt-BR" href="https://discord.com/invite/gtps3?locale=pt-BR" />
<meta rel="alternate" hreflang="en-GB" href="https://discord.com/invite/gtps3?locale=en-GB" />
<meta rel="alternate" hreflang="zh-CN" href="https://discord.com/invite/gtps3?locale=zh-CN" />
<meta property="og:image" content="https://cdn.discordapp.com/splashes/742792944079208540/b57693d635261d22d686a47d8a7501d6.jpg?size=512" />
<meta property="og:image:type" content="image/jpeg" />
<meta property="og:image:width" content="512" />
<meta property="og:image:height" content="512" />
<meta property="twitter:image" content="https://cdn.discordapp.com/splashes/742792944079208540/b57693d635261d22d686a47d8a7501d6.jpg?size=512" />
<link rel="stylesheet" href="/assets/40532.d5ac429defc661feb463.css" integrity="sha256-mWAfLu4FBwMrPhOCnVTdqoBCk125I5AxRm/LPyQx1qE= sha512-ySJRxGt4f3OI+QIaK/zwNrqZpZxbQX9hEXcwOMC/Pkkcu+1QTzVmlAWtHD/mg2LcpaNSVB8TWUoFepEOofhIsw=="><link rel="icon" href="/assets/ec2c34cadd4b5f4594415127380a85e6.ico" /><title>Growtopia Private Server | gtps.ps</title>  </head>

  <body>
    <div id="app-mount"></div><script nonce="MTQyLDEzMSw2NSwxMzEsMTQxLDU3LDEwNCwxNDY=">window.__OVERLAY__ = /overlay/.test(location.pathname)</script><script nonce="MTQyLDEzMSw2NSwxMzEsMTQxLDU3LDEwNCwxNDY=">window.__BILLING_STANDALONE__ = /^\/billing/.test(location.pathname)</script><script nonce="MTQyLDEzMSw2NSwxMzEsMTQxLDU3LDEwNCwxNDY=">window.GLOBAL_ENV = {
        API_ENDPOINT: '//discord.com/api',
        API_VERSION: 9,
        GATEWAY_ENDPOINT: 'wss://gateway.discord.gg',
        WEBAPP_ENDPOINT: '//discord.com',
        CDN_HOST: 'cdn.discordapp.com',
        ASSET_ENDPOINT: '//discord.com',
        MEDIA_PROXY_ENDPOINT: '//media.discordapp.net',
        WIDGET_ENDPOINT: '//discord.com/widget',
        INVITE_HOST: 'discord.gg',
        GUILD_TEMPLATE_HOST: 'discord.new',
        GIFT_CODE_HOST: 'discord.gift',
        RELEASE_CHANNEL: 'stable',
        MARKETING_ENDPOINT: '//discord.com',
        BRAINTREE_KEY: 'production_ktzp8hfp_49pp2rp4phym7387',
        STRIPE_KEY: 'pk_live_CUQtlpQUF0vufWpnpUmQvcdi',
        NETWORKING_ENDPOINT: '//router.discordapp.net',
        RTC_LATENCY_ENDPOINT: '//latency.discord.media/rtc',
        ACTIVITY_APPLICATION_HOST: 'discordsays.com',
        PROJECT_ENV: 'production',
        REMOTE_AUTH_ENDPOINT: '//remote-auth-gateway.discord.gg',
        SENTRY_TAGS: {"buildId":"bf26f2b19109f5857941c9fca36b253bfb1b92d3","buildType":"normal"},
        MIGRATION_SOURCE_ORIGIN: 'https://discordapp.com',
        MIGRATION_DESTINATION_ORIGIN: 'https://discord.com',
        HTML_TIMESTAMP: Date.now(),
        ALGOLIA_KEY: 'aca0d7082e4e63af5ba5917d5e96bed0',
        PUBLIC_PATH: '/assets/'
      };</script><script nonce="MTQyLDEzMSw2NSwxMzEsMTQxLDU3LDEwNCwxNDY=">!function(){if(null!=window.WebSocket){if(function(n){try{var e=localStorage.getItem(n);return null==e?null:JSON.parse(e)}catch(n){return null}}("token")&&!window.__OVERLAY__){var n=null!=window.DiscordNative||null!=window.require?"etf":"json",e=window.GLOBAL_ENV.GATEWAY_ENDPOINT+"/?encoding="+n+"&v="+window.GLOBAL_ENV.API_VERSION+"&compress=zlib-stream";console.log("[FAST CONNECT] connecting to: "+e);var o=new WebSocket(e);o.binaryType="arraybuffer";var t=Date.now(),i={open:!1,identify:!1,gateway:e,messages:[]};o.onopen=function(){console.log("[FAST CONNECT] connected in "+(Date.now()-t)+"ms"),i.open=!0},o.onclose=o.onerror=function(){window._ws=null},o.onmessage=function(n){i.messages.push(n)},window._ws={ws:o,state:i}}}}();</script><script src="/assets/624b0375a9da2afca797.js" integrity="sha256-aS9q2IMEatL4JTv11o2pEa8adCEEvuDoKobGfX0yD3Y= sha512-Ixj4oVE3cn3mUMrEtiQuDv5OU32EAJLjgYm80ZcOkCQSyt/8e3j4SXrpcWsNxbCd/p7iBFH7yDhzArSD7n0zgQ=="></script><script src="/assets/6b9f81f8a863c72005c9.js" integrity="sha256-/WPVjXnX/lA8yTvbnUKlDgN/XZuJCGcK5RdswhgTbCU= sha512-C6nRnkeaGd91um8LzCAz/GKVVoi7EpOrlZLKTvXJRgePPv9vIjiu+NLzBTsuI4swBBfS1RIwtgGuINiRsg7fsw=="></script><script src="/assets/00eaa6699fea04871182.js" integrity="sha256-WV3xw7WKaPV/hoHWnSqEo/jXXCet9kNWuuvg7NU13kA= sha512-K831eom6oG7VsVPKc/arx3ShsVXoRll5bjjowDKxGxo/lnUvguOwo8lU6q2kV03l9sYZADI9Tvo5cly8NcyOVw=="></script><script src="/assets/6e586326c1c259e2eca5.js" integrity="sha256-h0p+IPDQ4gYkfjQPmzsJO1N2LAeIX/Ud7g8i2Zy5jOw= sha512-tIVnC0xdFunIQU0Nlu7XxjerQ+x5CHWS3Syr91Y/D7X72kXLVeA/ErcOMl4Ot+YjcdLX7O3W7V4+eUkCqEeldQ=="></script>  <script nonce="MTQyLDEzMSw2NSwxMzEsMTQxLDU3LDEwNCwxNDY=">(function(){var js = "window['__CF$cv$params']={r:'7ed7f2bff8bcc396'};_cpo=document.createElement('script');_cpo.nonce='MTQyLDEzMSw2NSwxMzEsMTQxLDU3LDEwNCwxNDY=',_cpo.src='/cdn-cgi/challenge-platform/scripts/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = 'MTQyLDEzMSw2NSwxMzEsMTQxLDU3LDEwNCwxNDY=';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>
</html>
